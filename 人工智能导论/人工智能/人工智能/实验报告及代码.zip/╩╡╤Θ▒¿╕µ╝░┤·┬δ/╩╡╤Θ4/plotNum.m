function plotNum(testInput)
	imshow(reshape(testInput(:),9,7));
end